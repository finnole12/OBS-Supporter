# obs-websocket-dotnet
A .NET library wrote in C# to communicate with an obs-websocket server. Depends on [websocket-sharp](https://github.com/sta/websocket-sharp) and [JSON.Net](http://www.newtonsoft.com/json).

This library is available on the [NuGet gallery](https://www.nuget.org/packages/obs-websocket-dotnet). See the `TestClient` project for a working example.

[![Build status](https://ci.appveyor.com/api/projects/status/2mbqwwra6bhswvps)](https://ci.appveyor.com/project/Palakis/obs-websocket-dotnet)
